﻿namespace neftegaz
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.Информация = new System.Windows.Forms.TabPage();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.Газ = new System.Windows.Forms.TabPage();
            this.button2 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.richTextBox5 = new System.Windows.Forms.RichTextBox();
            this.richTextBox4 = new System.Windows.Forms.RichTextBox();
            this.richTextBox3 = new System.Windows.Forms.RichTextBox();
            this.richTextBox2 = new System.Windows.Forms.RichTextBox();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.Конденсат = new System.Windows.Forms.TabPage();
            this.button4 = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.richTextBox10 = new System.Windows.Forms.RichTextBox();
            this.richTextBox9 = new System.Windows.Forms.RichTextBox();
            this.richTextBox8 = new System.Windows.Forms.RichTextBox();
            this.richTextBox7 = new System.Windows.Forms.RichTextBox();
            this.richTextBox6 = new System.Windows.Forms.RichTextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.гди = new System.Windows.Forms.TabPage();
            this.шлейфы = new System.Windows.Forms.TabPage();
            this.оборудование = new System.Windows.Forms.TabPage();
            this.дегазация = new System.Windows.Forms.TabPage();
            this.химреагенты = new System.Windows.Forms.TabPage();
            this.отбор_газ = new System.Windows.Forms.TabPage();
            this.отбор_конденсат = new System.Windows.Forms.TabPage();
            this.Клапана = new System.Windows.Forms.TabPage();
            this.унос = new System.Windows.Forms.TabPage();
            this.расчет_плотности = new System.Windows.Forms.TabPage();
            this.расчет_з = new System.Windows.Forms.TabPage();
            this.Растворимость_газа = new System.Windows.Forms.TabPage();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.richTextBox13 = new System.Windows.Forms.RichTextBox();
            this.richTextBox12 = new System.Windows.Forms.RichTextBox();
            this.button5 = new System.Windows.Forms.Button();
            this.richTextBox11 = new System.Windows.Forms.RichTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.richTextBox14 = new System.Windows.Forms.RichTextBox();
            this.richTextBox15 = new System.Windows.Forms.RichTextBox();
            this.richTextBox16 = new System.Windows.Forms.RichTextBox();
            this.richTextBox17 = new System.Windows.Forms.RichTextBox();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.richTextBox18 = new System.Windows.Forms.RichTextBox();
            this.richTextBox19 = new System.Windows.Forms.RichTextBox();
            this.richTextBox20 = new System.Windows.Forms.RichTextBox();
            this.richTextBox21 = new System.Windows.Forms.RichTextBox();
            this.richTextBox22 = new System.Windows.Forms.RichTextBox();
            this.richTextBox23 = new System.Windows.Forms.RichTextBox();
            this.richTextBox24 = new System.Windows.Forms.RichTextBox();
            this.richTextBox25 = new System.Windows.Forms.RichTextBox();
            this.richTextBox26 = new System.Windows.Forms.RichTextBox();
            this.richTextBox27 = new System.Windows.Forms.RichTextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.richTextBox28 = new System.Windows.Forms.RichTextBox();
            this.richTextBox29 = new System.Windows.Forms.RichTextBox();
            this.richTextBox30 = new System.Windows.Forms.RichTextBox();
            this.richTextBox31 = new System.Windows.Forms.RichTextBox();
            this.richTextBox32 = new System.Windows.Forms.RichTextBox();
            this.richTextBox33 = new System.Windows.Forms.RichTextBox();
            this.richTextBox34 = new System.Windows.Forms.RichTextBox();
            this.richTextBox35 = new System.Windows.Forms.RichTextBox();
            this.richTextBox36 = new System.Windows.Forms.RichTextBox();
            this.richTextBox37 = new System.Windows.Forms.RichTextBox();
            this.button8 = new System.Windows.Forms.Button();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.richTextBox38 = new System.Windows.Forms.RichTextBox();
            this.richTextBox39 = new System.Windows.Forms.RichTextBox();
            this.richTextBox40 = new System.Windows.Forms.RichTextBox();
            this.richTextBox41 = new System.Windows.Forms.RichTextBox();
            this.richTextBox42 = new System.Windows.Forms.RichTextBox();
            this.button9 = new System.Windows.Forms.Button();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.richTextBox43 = new System.Windows.Forms.RichTextBox();
            this.richTextBox44 = new System.Windows.Forms.RichTextBox();
            this.richTextBox45 = new System.Windows.Forms.RichTextBox();
            this.richTextBox46 = new System.Windows.Forms.RichTextBox();
            this.richTextBox47 = new System.Windows.Forms.RichTextBox();
            this.button10 = new System.Windows.Forms.Button();
            this.label55 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.richTextBox48 = new System.Windows.Forms.RichTextBox();
            this.richTextBox49 = new System.Windows.Forms.RichTextBox();
            this.richTextBox50 = new System.Windows.Forms.RichTextBox();
            this.richTextBox51 = new System.Windows.Forms.RichTextBox();
            this.richTextBox52 = new System.Windows.Forms.RichTextBox();
            this.button11 = new System.Windows.Forms.Button();
            this.label63 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.button12 = new System.Windows.Forms.Button();
            this.richTextBox53 = new System.Windows.Forms.RichTextBox();
            this.richTextBox54 = new System.Windows.Forms.RichTextBox();
            this.richTextBox55 = new System.Windows.Forms.RichTextBox();
            this.richTextBox56 = new System.Windows.Forms.RichTextBox();
            this.richTextBox57 = new System.Windows.Forms.RichTextBox();
            this.label71 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.button13 = new System.Windows.Forms.Button();
            this.richTextBox58 = new System.Windows.Forms.RichTextBox();
            this.richTextBox59 = new System.Windows.Forms.RichTextBox();
            this.richTextBox60 = new System.Windows.Forms.RichTextBox();
            this.richTextBox61 = new System.Windows.Forms.RichTextBox();
            this.richTextBox62 = new System.Windows.Forms.RichTextBox();
            this.label77 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.label79 = new System.Windows.Forms.Label();
            this.label80 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.Информация.SuspendLayout();
            this.Газ.SuspendLayout();
            this.Конденсат.SuspendLayout();
            this.гди.SuspendLayout();
            this.шлейфы.SuspendLayout();
            this.оборудование.SuspendLayout();
            this.дегазация.SuspendLayout();
            this.химреагенты.SuspendLayout();
            this.отбор_газ.SuspendLayout();
            this.отбор_конденсат.SuspendLayout();
            this.Клапана.SuspendLayout();
            this.унос.SuspendLayout();
            this.расчет_плотности.SuspendLayout();
            this.расчет_з.SuspendLayout();
            this.Растворимость_газа.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(911, 592);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(110, 63);
            this.button1.TabIndex = 0;
            this.button1.Text = "Показать данные";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.Информация);
            this.tabControl1.Controls.Add(this.Газ);
            this.tabControl1.Controls.Add(this.Конденсат);
            this.tabControl1.Controls.Add(this.гди);
            this.tabControl1.Controls.Add(this.шлейфы);
            this.tabControl1.Controls.Add(this.оборудование);
            this.tabControl1.Controls.Add(this.дегазация);
            this.tabControl1.Controls.Add(this.химреагенты);
            this.tabControl1.Controls.Add(this.отбор_газ);
            this.tabControl1.Controls.Add(this.отбор_конденсат);
            this.tabControl1.Controls.Add(this.Клапана);
            this.tabControl1.Controls.Add(this.унос);
            this.tabControl1.Controls.Add(this.расчет_плотности);
            this.tabControl1.Controls.Add(this.расчет_з);
            this.tabControl1.Controls.Add(this.Растворимость_газа);
            this.tabControl1.Location = new System.Drawing.Point(12, 66);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1152, 705);
            this.tabControl1.TabIndex = 1;
            // 
            // Информация
            // 
            this.Информация.Controls.Add(this.label19);
            this.Информация.Controls.Add(this.label18);
            this.Информация.Controls.Add(this.label17);
            this.Информация.Controls.Add(this.label16);
            this.Информация.Controls.Add(this.label15);
            this.Информация.Controls.Add(this.label8);
            this.Информация.Location = new System.Drawing.Point(4, 29);
            this.Информация.Name = "Информация";
            this.Информация.Padding = new System.Windows.Forms.Padding(3);
            this.Информация.Size = new System.Drawing.Size(1144, 672);
            this.Информация.TabIndex = 1;
            this.Информация.Text = "Информация";
            this.Информация.UseVisualStyleBackColor = true;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(156, 247);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(854, 64);
            this.label19.TabIndex = 5;
            this.label19.Text = "Разработка программного обеспечения для определения\r\nнорматива технологических по" +
    "терь углеводородов при добыче";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(571, 585);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(183, 32);
            this.label18.TabIndex = 4;
            this.label18.Text = "Батышкин В.";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(571, 542);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(174, 32);
            this.label17.TabIndex = 3;
            this.label17.Text = "Трохачев С.";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(571, 498);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(163, 32);
            this.label16.TabIndex = 2;
            this.label16.Text = "Крайнов П.";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(302, 542);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(173, 32);
            this.label15.TabIndex = 1;
            this.label15.Text = "Выполнили:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(402, 171);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(352, 46);
            this.label8.TabIndex = 0;
            this.label8.Text = "Курсовая работа";
            // 
            // Газ
            // 
            this.Газ.Controls.Add(this.button2);
            this.Газ.Controls.Add(this.label7);
            this.Газ.Controls.Add(this.label6);
            this.Газ.Controls.Add(this.label5);
            this.Газ.Controls.Add(this.label4);
            this.Газ.Controls.Add(this.label3);
            this.Газ.Controls.Add(this.richTextBox5);
            this.Газ.Controls.Add(this.richTextBox4);
            this.Газ.Controls.Add(this.richTextBox3);
            this.Газ.Controls.Add(this.richTextBox2);
            this.Газ.Controls.Add(this.richTextBox1);
            this.Газ.Controls.Add(this.label2);
            this.Газ.Controls.Add(this.button1);
            this.Газ.Location = new System.Drawing.Point(4, 29);
            this.Газ.Name = "Газ";
            this.Газ.Padding = new System.Windows.Forms.Padding(3);
            this.Газ.Size = new System.Drawing.Size(1144, 672);
            this.Газ.TabIndex = 0;
            this.Газ.Text = "ИТОГО (ГАЗ)";
            this.Газ.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(137, 592);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(179, 63);
            this.button2.TabIndex = 12;
            this.button2.Text = "Информация из приказа Минэнерго";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(781, 20);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(51, 20);
            this.label7.TabIndex = 11;
            this.label7.Text = "label7";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(985, 68);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(51, 20);
            this.label6.TabIndex = 10;
            this.label6.Text = "label6";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(846, 68);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(51, 20);
            this.label5.TabIndex = 9;
            this.label5.Text = "label5";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(731, 68);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 20);
            this.label4.TabIndex = 8;
            this.label4.Text = "label4";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(563, 20);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(51, 20);
            this.label3.TabIndex = 7;
            this.label3.Text = "label3";
            // 
            // richTextBox5
            // 
            this.richTextBox5.Location = new System.Drawing.Point(567, 100);
            this.richTextBox5.Name = "richTextBox5";
            this.richTextBox5.Size = new System.Drawing.Size(98, 475);
            this.richTextBox5.TabIndex = 6;
            this.richTextBox5.Text = "";
            // 
            // richTextBox4
            // 
            this.richTextBox4.Location = new System.Drawing.Point(958, 100);
            this.richTextBox4.Name = "richTextBox4";
            this.richTextBox4.Size = new System.Drawing.Size(98, 475);
            this.richTextBox4.TabIndex = 5;
            this.richTextBox4.Text = "";
            // 
            // richTextBox3
            // 
            this.richTextBox3.Location = new System.Drawing.Point(834, 100);
            this.richTextBox3.Name = "richTextBox3";
            this.richTextBox3.Size = new System.Drawing.Size(98, 475);
            this.richTextBox3.TabIndex = 4;
            this.richTextBox3.Text = "";
            // 
            // richTextBox2
            // 
            this.richTextBox2.Location = new System.Drawing.Point(708, 100);
            this.richTextBox2.Name = "richTextBox2";
            this.richTextBox2.Size = new System.Drawing.Size(98, 475);
            this.richTextBox2.TabIndex = 3;
            this.richTextBox2.Text = "";
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(101, 100);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(420, 478);
            this.richTextBox1.TabIndex = 2;
            this.richTextBox1.Text = "";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(114, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "label2";
            // 
            // Конденсат
            // 
            this.Конденсат.Controls.Add(this.button4);
            this.Конденсат.Controls.Add(this.label14);
            this.Конденсат.Controls.Add(this.label13);
            this.Конденсат.Controls.Add(this.label12);
            this.Конденсат.Controls.Add(this.label11);
            this.Конденсат.Controls.Add(this.label10);
            this.Конденсат.Controls.Add(this.label9);
            this.Конденсат.Controls.Add(this.richTextBox10);
            this.Конденсат.Controls.Add(this.richTextBox9);
            this.Конденсат.Controls.Add(this.richTextBox8);
            this.Конденсат.Controls.Add(this.richTextBox7);
            this.Конденсат.Controls.Add(this.richTextBox6);
            this.Конденсат.Controls.Add(this.button3);
            this.Конденсат.Location = new System.Drawing.Point(4, 29);
            this.Конденсат.Name = "Конденсат";
            this.Конденсат.Padding = new System.Windows.Forms.Padding(3);
            this.Конденсат.Size = new System.Drawing.Size(1144, 672);
            this.Конденсат.TabIndex = 2;
            this.Конденсат.Text = "ИТОГО (КОНДЕНСАТ)";
            this.Конденсат.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(80, 564);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(178, 57);
            this.button4.TabIndex = 12;
            this.button4.Text = "Информация из приказа Минэнерго";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(991, 110);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(60, 20);
            this.label14.TabIndex = 11;
            this.label14.Text = "label14";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(818, 110);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(60, 20);
            this.label13.TabIndex = 10;
            this.label13.Text = "label13";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(694, 110);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(60, 20);
            this.label12.TabIndex = 9;
            this.label12.Text = "label12";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(760, 67);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(60, 20);
            this.label11.TabIndex = 8;
            this.label11.Text = "label11";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(572, 67);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(60, 20);
            this.label10.TabIndex = 7;
            this.label10.Text = "label10";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(115, 67);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(51, 20);
            this.label9.TabIndex = 6;
            this.label9.Text = "label9";
            // 
            // richTextBox10
            // 
            this.richTextBox10.Location = new System.Drawing.Point(564, 142);
            this.richTextBox10.Name = "richTextBox10";
            this.richTextBox10.Size = new System.Drawing.Size(106, 395);
            this.richTextBox10.TabIndex = 5;
            this.richTextBox10.Text = "";
            // 
            // richTextBox9
            // 
            this.richTextBox9.Location = new System.Drawing.Point(986, 142);
            this.richTextBox9.Name = "richTextBox9";
            this.richTextBox9.Size = new System.Drawing.Size(87, 395);
            this.richTextBox9.TabIndex = 4;
            this.richTextBox9.Text = "";
            // 
            // richTextBox8
            // 
            this.richTextBox8.Location = new System.Drawing.Point(812, 142);
            this.richTextBox8.Name = "richTextBox8";
            this.richTextBox8.Size = new System.Drawing.Size(151, 395);
            this.richTextBox8.TabIndex = 3;
            this.richTextBox8.Text = "";
            // 
            // richTextBox7
            // 
            this.richTextBox7.Location = new System.Drawing.Point(689, 142);
            this.richTextBox7.Name = "richTextBox7";
            this.richTextBox7.Size = new System.Drawing.Size(100, 395);
            this.richTextBox7.TabIndex = 2;
            this.richTextBox7.Text = "";
            // 
            // richTextBox6
            // 
            this.richTextBox6.Location = new System.Drawing.Point(80, 142);
            this.richTextBox6.Name = "richTextBox6";
            this.richTextBox6.Size = new System.Drawing.Size(468, 395);
            this.richTextBox6.TabIndex = 1;
            this.richTextBox6.Text = "";
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(948, 564);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(125, 57);
            this.button3.TabIndex = 0;
            this.button3.Text = "Показать данные";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // гди
            // 
            this.гди.Controls.Add(this.label33);
            this.гди.Controls.Add(this.label32);
            this.гди.Controls.Add(this.label31);
            this.гди.Controls.Add(this.label30);
            this.гди.Controls.Add(this.label29);
            this.гди.Controls.Add(this.label28);
            this.гди.Controls.Add(this.label27);
            this.гди.Controls.Add(this.label26);
            this.гди.Controls.Add(this.label25);
            this.гди.Controls.Add(this.label24);
            this.гди.Controls.Add(this.richTextBox23);
            this.гди.Controls.Add(this.richTextBox24);
            this.гди.Controls.Add(this.richTextBox25);
            this.гди.Controls.Add(this.richTextBox26);
            this.гди.Controls.Add(this.richTextBox27);
            this.гди.Controls.Add(this.richTextBox22);
            this.гди.Controls.Add(this.richTextBox21);
            this.гди.Controls.Add(this.richTextBox20);
            this.гди.Controls.Add(this.richTextBox19);
            this.гди.Controls.Add(this.richTextBox18);
            this.гди.Controls.Add(this.button7);
            this.гди.Location = new System.Drawing.Point(4, 29);
            this.гди.Name = "гди";
            this.гди.Padding = new System.Windows.Forms.Padding(3);
            this.гди.Size = new System.Drawing.Size(1144, 672);
            this.гди.TabIndex = 3;
            this.гди.Text = "ГДИ+ГКИ";
            this.гди.UseVisualStyleBackColor = true;
            // 
            // шлейфы
            // 
            this.шлейфы.Controls.Add(this.button15);
            this.шлейфы.Location = new System.Drawing.Point(4, 29);
            this.шлейфы.Name = "шлейфы";
            this.шлейфы.Size = new System.Drawing.Size(1144, 672);
            this.шлейфы.TabIndex = 4;
            this.шлейфы.Text = "Опорожнение (Шлейфы)";
            this.шлейфы.UseVisualStyleBackColor = true;
            // 
            // оборудование
            // 
            this.оборудование.Controls.Add(this.button16);
            this.оборудование.Location = new System.Drawing.Point(4, 29);
            this.оборудование.Name = "оборудование";
            this.оборудование.Size = new System.Drawing.Size(1144, 672);
            this.оборудование.TabIndex = 5;
            this.оборудование.Text = "Опорожнение (Оборудование)";
            this.оборудование.UseVisualStyleBackColor = true;
            // 
            // дегазация
            // 
            this.дегазация.Controls.Add(this.label48);
            this.дегазация.Controls.Add(this.label47);
            this.дегазация.Controls.Add(this.label46);
            this.дегазация.Controls.Add(this.label45);
            this.дегазация.Controls.Add(this.label44);
            this.дегазация.Controls.Add(this.label43);
            this.дегазация.Controls.Add(this.label42);
            this.дегазация.Controls.Add(this.label41);
            this.дегазация.Controls.Add(this.label40);
            this.дегазация.Controls.Add(this.label39);
            this.дегазация.Controls.Add(this.label38);
            this.дегазация.Controls.Add(this.label37);
            this.дегазация.Controls.Add(this.label36);
            this.дегазация.Controls.Add(this.label35);
            this.дегазация.Controls.Add(this.label34);
            this.дегазация.Controls.Add(this.button8);
            this.дегазация.Controls.Add(this.richTextBox33);
            this.дегазация.Controls.Add(this.richTextBox34);
            this.дегазация.Controls.Add(this.richTextBox35);
            this.дегазация.Controls.Add(this.richTextBox36);
            this.дегазация.Controls.Add(this.richTextBox37);
            this.дегазация.Controls.Add(this.richTextBox32);
            this.дегазация.Controls.Add(this.richTextBox31);
            this.дегазация.Controls.Add(this.richTextBox30);
            this.дегазация.Controls.Add(this.richTextBox29);
            this.дегазация.Controls.Add(this.richTextBox28);
            this.дегазация.Location = new System.Drawing.Point(4, 29);
            this.дегазация.Name = "дегазация";
            this.дегазация.Size = new System.Drawing.Size(1144, 672);
            this.дегазация.TabIndex = 6;
            this.дегазация.Text = "Дегазация жидкостей";
            this.дегазация.UseVisualStyleBackColor = true;
            // 
            // химреагенты
            // 
            this.химреагенты.Controls.Add(this.label54);
            this.химреагенты.Controls.Add(this.label53);
            this.химреагенты.Controls.Add(this.label52);
            this.химреагенты.Controls.Add(this.label51);
            this.химреагенты.Controls.Add(this.label50);
            this.химреагенты.Controls.Add(this.label49);
            this.химреагенты.Controls.Add(this.button9);
            this.химреагенты.Controls.Add(this.richTextBox42);
            this.химреагенты.Controls.Add(this.richTextBox41);
            this.химреагенты.Controls.Add(this.richTextBox40);
            this.химреагенты.Controls.Add(this.richTextBox39);
            this.химреагенты.Controls.Add(this.richTextBox38);
            this.химреагенты.Location = new System.Drawing.Point(4, 29);
            this.химреагенты.Name = "химреагенты";
            this.химреагенты.Size = new System.Drawing.Size(1144, 672);
            this.химреагенты.TabIndex = 7;
            this.химреагенты.Text = "Хим.реагенты";
            this.химреагенты.UseVisualStyleBackColor = true;
            // 
            // отбор_газ
            // 
            this.отбор_газ.Controls.Add(this.label62);
            this.отбор_газ.Controls.Add(this.label61);
            this.отбор_газ.Controls.Add(this.label60);
            this.отбор_газ.Controls.Add(this.label59);
            this.отбор_газ.Controls.Add(this.label58);
            this.отбор_газ.Controls.Add(this.label57);
            this.отбор_газ.Controls.Add(this.label56);
            this.отбор_газ.Controls.Add(this.label55);
            this.отбор_газ.Controls.Add(this.button10);
            this.отбор_газ.Controls.Add(this.richTextBox47);
            this.отбор_газ.Controls.Add(this.richTextBox46);
            this.отбор_газ.Controls.Add(this.richTextBox45);
            this.отбор_газ.Controls.Add(this.richTextBox44);
            this.отбор_газ.Controls.Add(this.richTextBox43);
            this.отбор_газ.Location = new System.Drawing.Point(4, 29);
            this.отбор_газ.Name = "отбор_газ";
            this.отбор_газ.Size = new System.Drawing.Size(1144, 672);
            this.отбор_газ.TabIndex = 8;
            this.отбор_газ.Text = "Отбор проб (газ)";
            this.отбор_газ.UseVisualStyleBackColor = true;
            // 
            // отбор_конденсат
            // 
            this.отбор_конденсат.Controls.Add(this.label70);
            this.отбор_конденсат.Controls.Add(this.label69);
            this.отбор_конденсат.Controls.Add(this.label68);
            this.отбор_конденсат.Controls.Add(this.label67);
            this.отбор_конденсат.Controls.Add(this.label66);
            this.отбор_конденсат.Controls.Add(this.label65);
            this.отбор_конденсат.Controls.Add(this.label64);
            this.отбор_конденсат.Controls.Add(this.label63);
            this.отбор_конденсат.Controls.Add(this.button11);
            this.отбор_конденсат.Controls.Add(this.richTextBox52);
            this.отбор_конденсат.Controls.Add(this.richTextBox51);
            this.отбор_конденсат.Controls.Add(this.richTextBox50);
            this.отбор_конденсат.Controls.Add(this.richTextBox49);
            this.отбор_конденсат.Controls.Add(this.richTextBox48);
            this.отбор_конденсат.Location = new System.Drawing.Point(4, 29);
            this.отбор_конденсат.Name = "отбор_конденсат";
            this.отбор_конденсат.Size = new System.Drawing.Size(1144, 672);
            this.отбор_конденсат.TabIndex = 9;
            this.отбор_конденсат.Text = "Отбор проб (Конденсат)";
            this.отбор_конденсат.UseVisualStyleBackColor = true;
            // 
            // Клапана
            // 
            this.Клапана.Controls.Add(this.label76);
            this.Клапана.Controls.Add(this.label75);
            this.Клапана.Controls.Add(this.label74);
            this.Клапана.Controls.Add(this.label73);
            this.Клапана.Controls.Add(this.label72);
            this.Клапана.Controls.Add(this.label71);
            this.Клапана.Controls.Add(this.richTextBox57);
            this.Клапана.Controls.Add(this.richTextBox56);
            this.Клапана.Controls.Add(this.richTextBox55);
            this.Клапана.Controls.Add(this.richTextBox54);
            this.Клапана.Controls.Add(this.richTextBox53);
            this.Клапана.Controls.Add(this.button12);
            this.Клапана.Location = new System.Drawing.Point(4, 29);
            this.Клапана.Name = "Клапана";
            this.Клапана.Size = new System.Drawing.Size(1144, 672);
            this.Клапана.TabIndex = 10;
            this.Клапана.Text = "Клапана";
            this.Клапана.UseVisualStyleBackColor = true;
            // 
            // унос
            // 
            this.унос.Controls.Add(this.label82);
            this.унос.Controls.Add(this.label81);
            this.унос.Controls.Add(this.label80);
            this.унос.Controls.Add(this.label79);
            this.унос.Controls.Add(this.label78);
            this.унос.Controls.Add(this.label77);
            this.унос.Controls.Add(this.richTextBox62);
            this.унос.Controls.Add(this.richTextBox61);
            this.унос.Controls.Add(this.richTextBox60);
            this.унос.Controls.Add(this.richTextBox59);
            this.унос.Controls.Add(this.richTextBox58);
            this.унос.Controls.Add(this.button13);
            this.унос.Location = new System.Drawing.Point(4, 29);
            this.унос.Name = "унос";
            this.унос.Size = new System.Drawing.Size(1144, 672);
            this.унос.TabIndex = 11;
            this.унос.Text = "Унос с жидкостью";
            this.унос.UseVisualStyleBackColor = true;
            // 
            // расчет_плотности
            // 
            this.расчет_плотности.Controls.Add(this.button14);
            this.расчет_плотности.Location = new System.Drawing.Point(4, 29);
            this.расчет_плотности.Name = "расчет_плотности";
            this.расчет_плотности.Size = new System.Drawing.Size(1144, 672);
            this.расчет_плотности.TabIndex = 12;
            this.расчет_плотности.Text = "Расчет плотности";
            this.расчет_плотности.UseVisualStyleBackColor = true;
            // 
            // расчет_з
            // 
            this.расчет_з.Controls.Add(this.button6);
            this.расчет_з.Controls.Add(this.richTextBox17);
            this.расчет_з.Controls.Add(this.richTextBox16);
            this.расчет_з.Controls.Add(this.richTextBox15);
            this.расчет_з.Controls.Add(this.richTextBox14);
            this.расчет_з.Location = new System.Drawing.Point(4, 29);
            this.расчет_з.Name = "расчет_з";
            this.расчет_з.Size = new System.Drawing.Size(1144, 672);
            this.расчет_з.TabIndex = 13;
            this.расчет_з.Text = "Расчет Z";
            this.расчет_з.UseVisualStyleBackColor = true;
            // 
            // Растворимость_газа
            // 
            this.Растворимость_газа.Controls.Add(this.label23);
            this.Растворимость_газа.Controls.Add(this.label22);
            this.Растворимость_газа.Controls.Add(this.label21);
            this.Растворимость_газа.Controls.Add(this.label20);
            this.Растворимость_газа.Controls.Add(this.richTextBox13);
            this.Растворимость_газа.Controls.Add(this.richTextBox12);
            this.Растворимость_газа.Controls.Add(this.button5);
            this.Растворимость_газа.Controls.Add(this.richTextBox11);
            this.Растворимость_газа.Location = new System.Drawing.Point(4, 29);
            this.Растворимость_газа.Name = "Растворимость_газа";
            this.Растворимость_газа.Size = new System.Drawing.Size(1144, 672);
            this.Растворимость_газа.TabIndex = 14;
            this.Растворимость_газа.Text = "Растворимость газа";
            this.Растворимость_газа.UseVisualStyleBackColor = true;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(175, 339);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(60, 20);
            this.label23.TabIndex = 7;
            this.label23.Text = "label23";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(76, 339);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(60, 20);
            this.label22.TabIndex = 6;
            this.label22.Text = "label22";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(107, 296);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(60, 20);
            this.label21.TabIndex = 5;
            this.label21.Text = "label21";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(912, 44);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(60, 20);
            this.label20.TabIndex = 4;
            this.label20.Text = "label20";
            // 
            // richTextBox13
            // 
            this.richTextBox13.Location = new System.Drawing.Point(76, 97);
            this.richTextBox13.Name = "richTextBox13";
            this.richTextBox13.Size = new System.Drawing.Size(338, 152);
            this.richTextBox13.TabIndex = 3;
            this.richTextBox13.Text = "";
            this.richTextBox13.TextChanged += new System.EventHandler(this.richTextBox13_TextChanged);
            // 
            // richTextBox12
            // 
            this.richTextBox12.Location = new System.Drawing.Point(107, 393);
            this.richTextBox12.Name = "richTextBox12";
            this.richTextBox12.Size = new System.Drawing.Size(107, 153);
            this.richTextBox12.TabIndex = 2;
            this.richTextBox12.Text = "";
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(864, 536);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(128, 58);
            this.button5.TabIndex = 1;
            this.button5.Text = "button5";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // richTextBox11
            // 
            this.richTextBox11.Location = new System.Drawing.Point(916, 97);
            this.richTextBox11.Name = "richTextBox11";
            this.richTextBox11.Size = new System.Drawing.Size(105, 104);
            this.richTextBox11.TabIndex = 0;
            this.richTextBox11.Text = "";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(439, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(359, 37);
            this.label1.TabIndex = 2;
            this.label1.Text = "Восточно-Прибрежное";
            // 
            // richTextBox14
            // 
            this.richTextBox14.Location = new System.Drawing.Point(46, 51);
            this.richTextBox14.Name = "richTextBox14";
            this.richTextBox14.Size = new System.Drawing.Size(336, 171);
            this.richTextBox14.TabIndex = 0;
            this.richTextBox14.Text = "";
            // 
            // richTextBox15
            // 
            this.richTextBox15.Location = new System.Drawing.Point(430, 51);
            this.richTextBox15.Name = "richTextBox15";
            this.richTextBox15.Size = new System.Drawing.Size(117, 171);
            this.richTextBox15.TabIndex = 1;
            this.richTextBox15.Text = "";
            // 
            // richTextBox16
            // 
            this.richTextBox16.Location = new System.Drawing.Point(46, 243);
            this.richTextBox16.Name = "richTextBox16";
            this.richTextBox16.Size = new System.Drawing.Size(100, 426);
            this.richTextBox16.TabIndex = 2;
            this.richTextBox16.Text = "";
            // 
            // richTextBox17
            // 
            this.richTextBox17.Location = new System.Drawing.Point(201, 243);
            this.richTextBox17.Name = "richTextBox17";
            this.richTextBox17.Size = new System.Drawing.Size(147, 426);
            this.richTextBox17.TabIndex = 3;
            this.richTextBox17.Text = "";
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(854, 222);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 23);
            this.button6.TabIndex = 4;
            this.button6.Text = "button6";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(1042, 583);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(75, 23);
            this.button7.TabIndex = 0;
            this.button7.Text = "button7";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // richTextBox18
            // 
            this.richTextBox18.Location = new System.Drawing.Point(32, 52);
            this.richTextBox18.Name = "richTextBox18";
            this.richTextBox18.Size = new System.Drawing.Size(60, 207);
            this.richTextBox18.TabIndex = 1;
            this.richTextBox18.Text = "";
            // 
            // richTextBox19
            // 
            this.richTextBox19.Location = new System.Drawing.Point(136, 52);
            this.richTextBox19.Name = "richTextBox19";
            this.richTextBox19.Size = new System.Drawing.Size(455, 207);
            this.richTextBox19.TabIndex = 2;
            this.richTextBox19.Text = "";
            // 
            // richTextBox20
            // 
            this.richTextBox20.Location = new System.Drawing.Point(629, 52);
            this.richTextBox20.Name = "richTextBox20";
            this.richTextBox20.Size = new System.Drawing.Size(115, 207);
            this.richTextBox20.TabIndex = 3;
            this.richTextBox20.Text = "";
            // 
            // richTextBox21
            // 
            this.richTextBox21.Location = new System.Drawing.Point(783, 52);
            this.richTextBox21.Name = "richTextBox21";
            this.richTextBox21.Size = new System.Drawing.Size(100, 207);
            this.richTextBox21.TabIndex = 4;
            this.richTextBox21.Text = "";
            // 
            // richTextBox22
            // 
            this.richTextBox22.Location = new System.Drawing.Point(950, 52);
            this.richTextBox22.Name = "richTextBox22";
            this.richTextBox22.Size = new System.Drawing.Size(100, 207);
            this.richTextBox22.TabIndex = 5;
            this.richTextBox22.Text = "";
            // 
            // richTextBox23
            // 
            this.richTextBox23.Location = new System.Drawing.Point(950, 329);
            this.richTextBox23.Name = "richTextBox23";
            this.richTextBox23.Size = new System.Drawing.Size(100, 207);
            this.richTextBox23.TabIndex = 10;
            this.richTextBox23.Text = "";
            // 
            // richTextBox24
            // 
            this.richTextBox24.Location = new System.Drawing.Point(783, 329);
            this.richTextBox24.Name = "richTextBox24";
            this.richTextBox24.Size = new System.Drawing.Size(100, 207);
            this.richTextBox24.TabIndex = 9;
            this.richTextBox24.Text = "";
            // 
            // richTextBox25
            // 
            this.richTextBox25.Location = new System.Drawing.Point(629, 329);
            this.richTextBox25.Name = "richTextBox25";
            this.richTextBox25.Size = new System.Drawing.Size(115, 207);
            this.richTextBox25.TabIndex = 8;
            this.richTextBox25.Text = "";
            // 
            // richTextBox26
            // 
            this.richTextBox26.Location = new System.Drawing.Point(136, 329);
            this.richTextBox26.Name = "richTextBox26";
            this.richTextBox26.Size = new System.Drawing.Size(455, 207);
            this.richTextBox26.TabIndex = 7;
            this.richTextBox26.Text = "";
            // 
            // richTextBox27
            // 
            this.richTextBox27.Location = new System.Drawing.Point(32, 329);
            this.richTextBox27.Name = "richTextBox27";
            this.richTextBox27.Size = new System.Drawing.Size(60, 207);
            this.richTextBox27.TabIndex = 6;
            this.richTextBox27.Text = "";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(32, 26);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(60, 20);
            this.label24.TabIndex = 11;
            this.label24.Text = "label24";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(32, 306);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(60, 20);
            this.label25.TabIndex = 12;
            this.label25.Text = "label25";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(310, 26);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(60, 20);
            this.label26.TabIndex = 13;
            this.label26.Text = "label26";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(319, 306);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(60, 20);
            this.label27.TabIndex = 14;
            this.label27.Text = "label27";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(646, 3);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(60, 20);
            this.label28.TabIndex = 15;
            this.label28.Text = "label28";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(646, 306);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(60, 20);
            this.label29.TabIndex = 16;
            this.label29.Text = "label29";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(793, 26);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(60, 20);
            this.label30.TabIndex = 17;
            this.label30.Text = "label30";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(793, 297);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(60, 20);
            this.label31.TabIndex = 18;
            this.label31.Text = "label31";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(964, 26);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(60, 20);
            this.label32.TabIndex = 19;
            this.label32.Text = "label32";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(964, 306);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(60, 20);
            this.label33.TabIndex = 20;
            this.label33.Text = "label33";
            // 
            // richTextBox28
            // 
            this.richTextBox28.Location = new System.Drawing.Point(31, 103);
            this.richTextBox28.Name = "richTextBox28";
            this.richTextBox28.Size = new System.Drawing.Size(45, 205);
            this.richTextBox28.TabIndex = 0;
            this.richTextBox28.Text = "";
            // 
            // richTextBox29
            // 
            this.richTextBox29.Location = new System.Drawing.Point(92, 103);
            this.richTextBox29.Name = "richTextBox29";
            this.richTextBox29.Size = new System.Drawing.Size(690, 205);
            this.richTextBox29.TabIndex = 1;
            this.richTextBox29.Text = "";
            // 
            // richTextBox30
            // 
            this.richTextBox30.Location = new System.Drawing.Point(811, 103);
            this.richTextBox30.Name = "richTextBox30";
            this.richTextBox30.Size = new System.Drawing.Size(93, 205);
            this.richTextBox30.TabIndex = 2;
            this.richTextBox30.Text = "";
            // 
            // richTextBox31
            // 
            this.richTextBox31.Location = new System.Drawing.Point(921, 103);
            this.richTextBox31.Name = "richTextBox31";
            this.richTextBox31.Size = new System.Drawing.Size(100, 205);
            this.richTextBox31.TabIndex = 3;
            this.richTextBox31.Text = "";
            // 
            // richTextBox32
            // 
            this.richTextBox32.Location = new System.Drawing.Point(1039, 103);
            this.richTextBox32.Name = "richTextBox32";
            this.richTextBox32.Size = new System.Drawing.Size(90, 205);
            this.richTextBox32.TabIndex = 4;
            this.richTextBox32.Text = "";
            // 
            // richTextBox33
            // 
            this.richTextBox33.Location = new System.Drawing.Point(1039, 388);
            this.richTextBox33.Name = "richTextBox33";
            this.richTextBox33.Size = new System.Drawing.Size(90, 205);
            this.richTextBox33.TabIndex = 9;
            this.richTextBox33.Text = "";
            // 
            // richTextBox34
            // 
            this.richTextBox34.Location = new System.Drawing.Point(921, 388);
            this.richTextBox34.Name = "richTextBox34";
            this.richTextBox34.Size = new System.Drawing.Size(100, 205);
            this.richTextBox34.TabIndex = 8;
            this.richTextBox34.Text = "";
            // 
            // richTextBox35
            // 
            this.richTextBox35.Location = new System.Drawing.Point(811, 388);
            this.richTextBox35.Name = "richTextBox35";
            this.richTextBox35.Size = new System.Drawing.Size(93, 205);
            this.richTextBox35.TabIndex = 7;
            this.richTextBox35.Text = "";
            // 
            // richTextBox36
            // 
            this.richTextBox36.Location = new System.Drawing.Point(92, 388);
            this.richTextBox36.Name = "richTextBox36";
            this.richTextBox36.Size = new System.Drawing.Size(690, 205);
            this.richTextBox36.TabIndex = 6;
            this.richTextBox36.Text = "";
            // 
            // richTextBox37
            // 
            this.richTextBox37.Location = new System.Drawing.Point(31, 388);
            this.richTextBox37.Name = "richTextBox37";
            this.richTextBox37.Size = new System.Drawing.Size(45, 205);
            this.richTextBox37.TabIndex = 5;
            this.richTextBox37.Text = "";
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(1054, 615);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(75, 23);
            this.button8.TabIndex = 10;
            this.button8.Text = "button8";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(31, 57);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(60, 20);
            this.label34.TabIndex = 11;
            this.label34.Text = "label34";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(27, 355);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(60, 20);
            this.label35.TabIndex = 12;
            this.label35.Text = "label35";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(405, 57);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(60, 20);
            this.label36.TabIndex = 13;
            this.label36.Text = "label36";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(405, 355);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(60, 20);
            this.label37.TabIndex = 14;
            this.label37.Text = "label37";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(818, 57);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(60, 20);
            this.label38.TabIndex = 15;
            this.label38.Text = "label38";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(818, 355);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(60, 20);
            this.label39.TabIndex = 16;
            this.label39.Text = "label39";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(941, 40);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(60, 20);
            this.label40.TabIndex = 17;
            this.label40.Text = "label40";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(941, 327);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(60, 20);
            this.label41.TabIndex = 18;
            this.label41.Text = "label41";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(941, 80);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(60, 20);
            this.label42.TabIndex = 19;
            this.label42.Text = "label42";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(941, 365);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(60, 20);
            this.label43.TabIndex = 20;
            this.label43.Text = "label43";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(1050, 57);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(60, 20);
            this.label44.TabIndex = 21;
            this.label44.Text = "label44";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(1050, 355);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(60, 20);
            this.label45.TabIndex = 22;
            this.label45.Text = "label45";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(316, 0);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(60, 20);
            this.label46.TabIndex = 23;
            this.label46.Text = "label46";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(226, 30);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(60, 20);
            this.label47.TabIndex = 24;
            this.label47.Text = "label47";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(237, 327);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(60, 20);
            this.label48.TabIndex = 25;
            this.label48.Text = "label48";
            // 
            // richTextBox38
            // 
            this.richTextBox38.Location = new System.Drawing.Point(34, 212);
            this.richTextBox38.Name = "richTextBox38";
            this.richTextBox38.Size = new System.Drawing.Size(100, 221);
            this.richTextBox38.TabIndex = 0;
            this.richTextBox38.Text = "";
            // 
            // richTextBox39
            // 
            this.richTextBox39.Location = new System.Drawing.Point(192, 212);
            this.richTextBox39.Name = "richTextBox39";
            this.richTextBox39.Size = new System.Drawing.Size(347, 96);
            this.richTextBox39.TabIndex = 1;
            this.richTextBox39.Text = "";
            // 
            // richTextBox40
            // 
            this.richTextBox40.Location = new System.Drawing.Point(588, 212);
            this.richTextBox40.Name = "richTextBox40";
            this.richTextBox40.Size = new System.Drawing.Size(100, 96);
            this.richTextBox40.TabIndex = 2;
            this.richTextBox40.Text = "";
            // 
            // richTextBox41
            // 
            this.richTextBox41.Location = new System.Drawing.Point(740, 212);
            this.richTextBox41.Name = "richTextBox41";
            this.richTextBox41.Size = new System.Drawing.Size(100, 96);
            this.richTextBox41.TabIndex = 3;
            this.richTextBox41.Text = "";
            // 
            // richTextBox42
            // 
            this.richTextBox42.Location = new System.Drawing.Point(895, 212);
            this.richTextBox42.Name = "richTextBox42";
            this.richTextBox42.Size = new System.Drawing.Size(100, 96);
            this.richTextBox42.TabIndex = 4;
            this.richTextBox42.Text = "";
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(1055, 575);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(75, 23);
            this.button9.TabIndex = 5;
            this.button9.Text = "button9";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(34, 173);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(60, 20);
            this.label49.TabIndex = 6;
            this.label49.Text = "label49";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(188, 173);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(60, 20);
            this.label50.TabIndex = 7;
            this.label50.Text = "label50";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(584, 173);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(60, 20);
            this.label51.TabIndex = 8;
            this.label51.Text = "label51";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(736, 173);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(60, 20);
            this.label52.TabIndex = 9;
            this.label52.Text = "label52";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(891, 173);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(60, 20);
            this.label53.TabIndex = 10;
            this.label53.Text = "label53";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(277, 69);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(60, 20);
            this.label54.TabIndex = 11;
            this.label54.Text = "label54";
            // 
            // richTextBox43
            // 
            this.richTextBox43.Location = new System.Drawing.Point(30, 137);
            this.richTextBox43.Name = "richTextBox43";
            this.richTextBox43.Size = new System.Drawing.Size(100, 96);
            this.richTextBox43.TabIndex = 0;
            this.richTextBox43.Text = "";
            // 
            // richTextBox44
            // 
            this.richTextBox44.Location = new System.Drawing.Point(173, 137);
            this.richTextBox44.Name = "richTextBox44";
            this.richTextBox44.Size = new System.Drawing.Size(345, 96);
            this.richTextBox44.TabIndex = 1;
            this.richTextBox44.Text = "";
            // 
            // richTextBox45
            // 
            this.richTextBox45.Location = new System.Drawing.Point(572, 137);
            this.richTextBox45.Name = "richTextBox45";
            this.richTextBox45.Size = new System.Drawing.Size(100, 96);
            this.richTextBox45.TabIndex = 2;
            this.richTextBox45.Text = "";
            // 
            // richTextBox46
            // 
            this.richTextBox46.Location = new System.Drawing.Point(723, 137);
            this.richTextBox46.Name = "richTextBox46";
            this.richTextBox46.Size = new System.Drawing.Size(100, 96);
            this.richTextBox46.TabIndex = 3;
            this.richTextBox46.Text = "";
            // 
            // richTextBox47
            // 
            this.richTextBox47.Location = new System.Drawing.Point(873, 137);
            this.richTextBox47.Name = "richTextBox47";
            this.richTextBox47.Size = new System.Drawing.Size(100, 96);
            this.richTextBox47.TabIndex = 4;
            this.richTextBox47.Text = "";
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(1038, 581);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(75, 23);
            this.button10.TabIndex = 5;
            this.button10.Text = "button10";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(40, 66);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(60, 20);
            this.label55.TabIndex = 6;
            this.label55.Text = "label55";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(209, 66);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(60, 20);
            this.label56.TabIndex = 7;
            this.label56.Text = "label56";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(586, 66);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(60, 20);
            this.label57.TabIndex = 8;
            this.label57.Text = "label57";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(738, 52);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(60, 20);
            this.label58.TabIndex = 9;
            this.label58.Text = "label58";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(738, 91);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(60, 20);
            this.label59.TabIndex = 10;
            this.label59.Text = "label59";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(891, 66);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(60, 20);
            this.label60.TabIndex = 11;
            this.label60.Text = "label60";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(327, 16);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(60, 20);
            this.label61.TabIndex = 12;
            this.label61.Text = "label61";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(381, 114);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(60, 20);
            this.label62.TabIndex = 13;
            this.label62.Text = "label62";
            // 
            // richTextBox48
            // 
            this.richTextBox48.Location = new System.Drawing.Point(29, 186);
            this.richTextBox48.Name = "richTextBox48";
            this.richTextBox48.Size = new System.Drawing.Size(100, 96);
            this.richTextBox48.TabIndex = 0;
            this.richTextBox48.Text = "";
            // 
            // richTextBox49
            // 
            this.richTextBox49.Location = new System.Drawing.Point(193, 186);
            this.richTextBox49.Name = "richTextBox49";
            this.richTextBox49.Size = new System.Drawing.Size(358, 96);
            this.richTextBox49.TabIndex = 1;
            this.richTextBox49.Text = "";
            // 
            // richTextBox50
            // 
            this.richTextBox50.Location = new System.Drawing.Point(613, 186);
            this.richTextBox50.Name = "richTextBox50";
            this.richTextBox50.Size = new System.Drawing.Size(100, 96);
            this.richTextBox50.TabIndex = 2;
            this.richTextBox50.Text = "";
            // 
            // richTextBox51
            // 
            this.richTextBox51.Location = new System.Drawing.Point(755, 186);
            this.richTextBox51.Name = "richTextBox51";
            this.richTextBox51.Size = new System.Drawing.Size(100, 96);
            this.richTextBox51.TabIndex = 3;
            this.richTextBox51.Text = "";
            // 
            // richTextBox52
            // 
            this.richTextBox52.Location = new System.Drawing.Point(895, 186);
            this.richTextBox52.Name = "richTextBox52";
            this.richTextBox52.Size = new System.Drawing.Size(100, 96);
            this.richTextBox52.TabIndex = 4;
            this.richTextBox52.Text = "";
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(1025, 575);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(75, 23);
            this.button11.TabIndex = 5;
            this.button11.Text = "button11";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(29, 80);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(60, 20);
            this.label63.TabIndex = 6;
            this.label63.Text = "label63";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(206, 80);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(60, 20);
            this.label64.TabIndex = 7;
            this.label64.Text = "label64";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(626, 80);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(60, 20);
            this.label65.TabIndex = 8;
            this.label65.Text = "label65";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(765, 60);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(60, 20);
            this.label66.TabIndex = 9;
            this.label66.Text = "label66";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Location = new System.Drawing.Point(765, 93);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(60, 20);
            this.label67.TabIndex = 10;
            this.label67.Text = "label67";
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(911, 80);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(60, 20);
            this.label68.TabIndex = 11;
            this.label68.Text = "label68";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Location = new System.Drawing.Point(491, 20);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(60, 20);
            this.label69.TabIndex = 12;
            this.label69.Text = "label69";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Location = new System.Drawing.Point(491, 135);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(60, 20);
            this.label70.TabIndex = 13;
            this.label70.Text = "label70";
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(1037, 594);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(75, 23);
            this.button12.TabIndex = 0;
            this.button12.Text = "button12";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // richTextBox53
            // 
            this.richTextBox53.Location = new System.Drawing.Point(33, 114);
            this.richTextBox53.Name = "richTextBox53";
            this.richTextBox53.Size = new System.Drawing.Size(100, 96);
            this.richTextBox53.TabIndex = 1;
            this.richTextBox53.Text = "";
            // 
            // richTextBox54
            // 
            this.richTextBox54.Location = new System.Drawing.Point(189, 114);
            this.richTextBox54.Name = "richTextBox54";
            this.richTextBox54.Size = new System.Drawing.Size(372, 96);
            this.richTextBox54.TabIndex = 2;
            this.richTextBox54.Text = "";
            // 
            // richTextBox55
            // 
            this.richTextBox55.Location = new System.Drawing.Point(633, 114);
            this.richTextBox55.Name = "richTextBox55";
            this.richTextBox55.Size = new System.Drawing.Size(100, 96);
            this.richTextBox55.TabIndex = 3;
            this.richTextBox55.Text = "";
            // 
            // richTextBox56
            // 
            this.richTextBox56.Location = new System.Drawing.Point(797, 114);
            this.richTextBox56.Name = "richTextBox56";
            this.richTextBox56.Size = new System.Drawing.Size(100, 96);
            this.richTextBox56.TabIndex = 4;
            this.richTextBox56.Text = "";
            // 
            // richTextBox57
            // 
            this.richTextBox57.Location = new System.Drawing.Point(956, 114);
            this.richTextBox57.Name = "richTextBox57";
            this.richTextBox57.Size = new System.Drawing.Size(100, 96);
            this.richTextBox57.TabIndex = 5;
            this.richTextBox57.Text = "";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Location = new System.Drawing.Point(33, 56);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(60, 20);
            this.label71.TabIndex = 6;
            this.label71.Text = "label71";
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Location = new System.Drawing.Point(203, 56);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(60, 20);
            this.label72.TabIndex = 7;
            this.label72.Text = "label72";
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Location = new System.Drawing.Point(629, 56);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(60, 20);
            this.label73.TabIndex = 8;
            this.label73.Text = "label73";
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Location = new System.Drawing.Point(811, 66);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(60, 20);
            this.label74.TabIndex = 9;
            this.label74.Text = "label74";
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Location = new System.Drawing.Point(972, 66);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(60, 20);
            this.label75.TabIndex = 10;
            this.label75.Text = "label75";
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Location = new System.Drawing.Point(426, 12);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(60, 20);
            this.label76.TabIndex = 11;
            this.label76.Text = "label76";
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(1015, 601);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(75, 23);
            this.button13.TabIndex = 0;
            this.button13.Text = "button13";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // richTextBox58
            // 
            this.richTextBox58.Location = new System.Drawing.Point(28, 139);
            this.richTextBox58.Name = "richTextBox58";
            this.richTextBox58.Size = new System.Drawing.Size(100, 96);
            this.richTextBox58.TabIndex = 1;
            this.richTextBox58.Text = "";
            // 
            // richTextBox59
            // 
            this.richTextBox59.Location = new System.Drawing.Point(189, 139);
            this.richTextBox59.Name = "richTextBox59";
            this.richTextBox59.Size = new System.Drawing.Size(339, 96);
            this.richTextBox59.TabIndex = 2;
            this.richTextBox59.Text = "";
            // 
            // richTextBox60
            // 
            this.richTextBox60.Location = new System.Drawing.Point(591, 139);
            this.richTextBox60.Name = "richTextBox60";
            this.richTextBox60.Size = new System.Drawing.Size(100, 96);
            this.richTextBox60.TabIndex = 3;
            this.richTextBox60.Text = "";
            // 
            // richTextBox61
            // 
            this.richTextBox61.Location = new System.Drawing.Point(748, 139);
            this.richTextBox61.Name = "richTextBox61";
            this.richTextBox61.Size = new System.Drawing.Size(100, 96);
            this.richTextBox61.TabIndex = 4;
            this.richTextBox61.Text = "";
            // 
            // richTextBox62
            // 
            this.richTextBox62.Location = new System.Drawing.Point(897, 139);
            this.richTextBox62.Name = "richTextBox62";
            this.richTextBox62.Size = new System.Drawing.Size(100, 96);
            this.richTextBox62.TabIndex = 5;
            this.richTextBox62.Text = "";
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Location = new System.Drawing.Point(28, 93);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(60, 20);
            this.label77.TabIndex = 6;
            this.label77.Text = "label77";
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Location = new System.Drawing.Point(220, 93);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(60, 20);
            this.label78.TabIndex = 7;
            this.label78.Text = "label78";
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Location = new System.Drawing.Point(603, 82);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(60, 20);
            this.label79.TabIndex = 8;
            this.label79.Text = "label79";
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Location = new System.Drawing.Point(775, 93);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(60, 20);
            this.label80.TabIndex = 9;
            this.label80.Text = "label80";
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Location = new System.Drawing.Point(915, 93);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(60, 20);
            this.label81.TabIndex = 10;
            this.label81.Text = "label81";
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Location = new System.Drawing.Point(515, 27);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(60, 20);
            this.label82.TabIndex = 11;
            this.label82.Text = "label82";
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(1030, 579);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(75, 23);
            this.button14.TabIndex = 0;
            this.button14.Text = "button14";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(1009, 576);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(75, 23);
            this.button15.TabIndex = 0;
            this.button15.Text = "button15";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(1000, 592);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(75, 23);
            this.button16.TabIndex = 0;
            this.button16.Text = "button16";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1176, 783);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Курсовая работа";
            this.tabControl1.ResumeLayout(false);
            this.Информация.ResumeLayout(false);
            this.Информация.PerformLayout();
            this.Газ.ResumeLayout(false);
            this.Газ.PerformLayout();
            this.Конденсат.ResumeLayout(false);
            this.Конденсат.PerformLayout();
            this.гди.ResumeLayout(false);
            this.гди.PerformLayout();
            this.шлейфы.ResumeLayout(false);
            this.оборудование.ResumeLayout(false);
            this.дегазация.ResumeLayout(false);
            this.дегазация.PerformLayout();
            this.химреагенты.ResumeLayout(false);
            this.химреагенты.PerformLayout();
            this.отбор_газ.ResumeLayout(false);
            this.отбор_газ.PerformLayout();
            this.отбор_конденсат.ResumeLayout(false);
            this.отбор_конденсат.PerformLayout();
            this.Клапана.ResumeLayout(false);
            this.Клапана.PerformLayout();
            this.унос.ResumeLayout(false);
            this.унос.PerformLayout();
            this.расчет_плотности.ResumeLayout(false);
            this.расчет_з.ResumeLayout(false);
            this.Растворимость_газа.ResumeLayout(false);
            this.Растворимость_газа.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage Информация;
        private System.Windows.Forms.TabPage Конденсат;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RichTextBox richTextBox2;
        private System.Windows.Forms.RichTextBox richTextBox4;
        private System.Windows.Forms.RichTextBox richTextBox3;
        private System.Windows.Forms.RichTextBox richTextBox5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TabPage гди;
        public System.Windows.Forms.TabPage Газ;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.RichTextBox richTextBox10;
        private System.Windows.Forms.RichTextBox richTextBox9;
        private System.Windows.Forms.RichTextBox richTextBox8;
        private System.Windows.Forms.RichTextBox richTextBox7;
        private System.Windows.Forms.RichTextBox richTextBox6;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TabPage шлейфы;
        private System.Windows.Forms.TabPage оборудование;
        private System.Windows.Forms.TabPage дегазация;
        private System.Windows.Forms.TabPage химреагенты;
        private System.Windows.Forms.TabPage отбор_газ;
        private System.Windows.Forms.TabPage отбор_конденсат;
        private System.Windows.Forms.TabPage Клапана;
        private System.Windows.Forms.TabPage унос;
        private System.Windows.Forms.TabPage расчет_плотности;
        private System.Windows.Forms.TabPage расчет_з;
        private System.Windows.Forms.TabPage Растворимость_газа;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.RichTextBox richTextBox11;
        private System.Windows.Forms.RichTextBox richTextBox12;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.RichTextBox richTextBox13;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.RichTextBox richTextBox17;
        private System.Windows.Forms.RichTextBox richTextBox16;
        private System.Windows.Forms.RichTextBox richTextBox15;
        private System.Windows.Forms.RichTextBox richTextBox14;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.RichTextBox richTextBox23;
        private System.Windows.Forms.RichTextBox richTextBox24;
        private System.Windows.Forms.RichTextBox richTextBox25;
        private System.Windows.Forms.RichTextBox richTextBox26;
        private System.Windows.Forms.RichTextBox richTextBox27;
        private System.Windows.Forms.RichTextBox richTextBox22;
        private System.Windows.Forms.RichTextBox richTextBox21;
        private System.Windows.Forms.RichTextBox richTextBox20;
        private System.Windows.Forms.RichTextBox richTextBox19;
        private System.Windows.Forms.RichTextBox richTextBox18;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.RichTextBox richTextBox33;
        private System.Windows.Forms.RichTextBox richTextBox34;
        private System.Windows.Forms.RichTextBox richTextBox35;
        private System.Windows.Forms.RichTextBox richTextBox36;
        private System.Windows.Forms.RichTextBox richTextBox37;
        private System.Windows.Forms.RichTextBox richTextBox32;
        private System.Windows.Forms.RichTextBox richTextBox31;
        private System.Windows.Forms.RichTextBox richTextBox30;
        private System.Windows.Forms.RichTextBox richTextBox29;
        private System.Windows.Forms.RichTextBox richTextBox28;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.RichTextBox richTextBox42;
        private System.Windows.Forms.RichTextBox richTextBox41;
        private System.Windows.Forms.RichTextBox richTextBox40;
        private System.Windows.Forms.RichTextBox richTextBox39;
        private System.Windows.Forms.RichTextBox richTextBox38;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.RichTextBox richTextBox47;
        private System.Windows.Forms.RichTextBox richTextBox46;
        private System.Windows.Forms.RichTextBox richTextBox45;
        private System.Windows.Forms.RichTextBox richTextBox44;
        private System.Windows.Forms.RichTextBox richTextBox43;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.RichTextBox richTextBox52;
        private System.Windows.Forms.RichTextBox richTextBox51;
        private System.Windows.Forms.RichTextBox richTextBox50;
        private System.Windows.Forms.RichTextBox richTextBox49;
        private System.Windows.Forms.RichTextBox richTextBox48;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.RichTextBox richTextBox57;
        private System.Windows.Forms.RichTextBox richTextBox56;
        private System.Windows.Forms.RichTextBox richTextBox55;
        private System.Windows.Forms.RichTextBox richTextBox54;
        private System.Windows.Forms.RichTextBox richTextBox53;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.RichTextBox richTextBox62;
        private System.Windows.Forms.RichTextBox richTextBox61;
        private System.Windows.Forms.RichTextBox richTextBox60;
        private System.Windows.Forms.RichTextBox richTextBox59;
        private System.Windows.Forms.RichTextBox richTextBox58;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button14;
    }
}

